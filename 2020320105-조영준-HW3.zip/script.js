function dateToString(dt) {
    let year = dt.getFullYear();
    let month = (dt.getMonth() + 1).toString().padStart(2, '0');
    let date = dt.getDate().toString().padStart(2, '0');
    let hour = dt.getHours().toString().padStart(2, '0');
    let minute = dt.getMinutes().toString().padStart(2, '0');
    let seconds = dt.getSeconds().toString().padStart(2, '0');
    return `${year}-${month}-${date} ${hour}:${minute}:${seconds}`;
}

function warnEmptyComment() {
    return alert('Submit a comment!');
}

var counts = 2;

function submitComment() {
    // Your code here
    var text = document.getElementById('new-comment');
    const count = document.getElementById('comments-count');

    if (text.value==''){
        warnEmptyComment();
    } else{
        //코멘트 수 세기
        counts++;
        count.innerHTML = counts;

        //댓글 추가하기
        var input = text.value;
        var comment = document.getElementById('comments');
        var divNode = document.createElement("div");
        var date = document.createElement("div");
        var content = document.createElement("div"); 

        divNode.setAttribute('class','comment-row');
        date.setAttribute('class','comment-date');
        content.setAttribute('class','comment-content');
        
        var today = new Date();
        date.innerHTML = dateToString(today);
        content.innerHTML = input;

        divNode.appendChild(date);
        divNode.appendChild(content);
        comment.appendChild(divNode);


        //댓글창 비우기
        text.value = '';
        
    }

}
